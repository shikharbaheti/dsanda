// implementation of the DLList class

#include <stdexcept>
#include "DLList.h"


// extend runtime_error from <stdexcept>
struct EmptyDLList : public std::runtime_error {
  explicit EmptyDLList(char const* msg=nullptr): runtime_error(msg) {}
};

// copy constructor
DLList::DLList(const DLList& dll)
{
  // Initialize the list
  header.next = &trailer;
  trailer.prev = &header;
  
  /* Complete this function */
}
// move constructor
DLList::DLList(DLList&& dll)
{
  /* Complete this function */
}

// copy assignment operator
DLList& DLList::operator=(const DLList& dll)
{
  /* Complete this function */
  return *this;
}

// move assignment operator
DLList& DLList::operator=(DLList&& dll)
{
  /* Complete this function */
  return *this;
}

// destructor
DLList::~DLList()
{
  /* Complete this function */
}

// insert a new object as the first one
void DLList::insert_first(int obj)
{ 
  /* Complete this function */
}

// insert a new object as the last one
void DLList::insert_last(int obj)
{
  /* Complete this function */
}

// remove the first node from the list
int DLList::remove_first()
{ 
  /* Complete this function */
}

// remove the last node from the list
int DLList::remove_last()
{
  /* Complete this function */
}

// return the first object (do not remove)
int DLList::first() const
{ 
  /* Complete this function */
}

// return the last object (do not remove)
int DLList::last() const
{
  /* Complete this function */
}

// insert a new node after the node p
void DLList::insert_after(DLListNode &p, int obj)
{
  /* Complete this function */
}

// insert a new node before the node p
void DLList::insert_before(DLListNode &p, int obj)
{
  /* Complete this function */
}

// remove the node after the node p
int DLList::remove_after(DLListNode &p)
{
  /* Complete this function */
}

// remove the node before the node p
int DLList::remove_before(DLListNode &p)
{
  /* Complete this function */
}

// output operator
ostream& operator<<(ostream& out, const DLList& dll)
{  
  /* Complete this function */

  return out;
}
